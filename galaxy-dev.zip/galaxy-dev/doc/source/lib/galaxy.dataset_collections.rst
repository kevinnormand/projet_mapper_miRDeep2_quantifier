galaxy.dataset_collections package
==================================

.. automodule:: galaxy.dataset_collections
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    galaxy.dataset_collections.types

Submodules
----------

galaxy.dataset_collections.builder module
-----------------------------------------

.. automodule:: galaxy.dataset_collections.builder
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.dataset_collections.matching module
------------------------------------------

.. automodule:: galaxy.dataset_collections.matching
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.dataset_collections.registry module
------------------------------------------

.. automodule:: galaxy.dataset_collections.registry
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.dataset_collections.structure module
-------------------------------------------

.. automodule:: galaxy.dataset_collections.structure
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.dataset_collections.subcollections module
------------------------------------------------

.. automodule:: galaxy.dataset_collections.subcollections
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.dataset_collections.type_description module
--------------------------------------------------

.. automodule:: galaxy.dataset_collections.type_description
    :members:
    :undoc-members:
    :show-inheritance:


