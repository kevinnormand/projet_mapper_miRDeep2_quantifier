galaxy.forms package
====================

.. automodule:: galaxy.forms
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

galaxy.forms.forms module
-------------------------

.. automodule:: galaxy.forms.forms
    :members:
    :undoc-members:
    :show-inheritance:


