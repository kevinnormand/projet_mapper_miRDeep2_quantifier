#!/usr/bin/env python

import sys

sys.exit("This script has been deprecated, replaced by the set of scripts in <galaxy_distribution>/scripts/cleanup_datsets/."
         "See https://wiki.galaxyproject.org/Admin/Config/Performance/Purge%20Histories%20and%20Datasets for more information.")
