galaxy.actions package
======================

.. automodule:: galaxy.actions
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

galaxy.actions.admin module
---------------------------

.. automodule:: galaxy.actions.admin
    :members:
    :undoc-members:
    :show-inheritance:


