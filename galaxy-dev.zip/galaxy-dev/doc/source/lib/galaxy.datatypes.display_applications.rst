galaxy.datatypes.display_applications package
=============================================

.. automodule:: galaxy.datatypes.display_applications
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

galaxy.datatypes.display_applications.application module
--------------------------------------------------------

.. automodule:: galaxy.datatypes.display_applications.application
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.datatypes.display_applications.parameters module
-------------------------------------------------------

.. automodule:: galaxy.datatypes.display_applications.parameters
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.datatypes.display_applications.util module
-------------------------------------------------

.. automodule:: galaxy.datatypes.display_applications.util
    :members:
    :undoc-members:
    :show-inheritance:


