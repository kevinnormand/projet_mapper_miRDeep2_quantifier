galaxy.dataset_collections.types package
========================================

.. automodule:: galaxy.dataset_collections.types
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

galaxy.dataset_collections.types.list module
--------------------------------------------

.. automodule:: galaxy.dataset_collections.types.list
    :members:
    :undoc-members:
    :show-inheritance:

galaxy.dataset_collections.types.paired module
----------------------------------------------

.. automodule:: galaxy.dataset_collections.types.paired
    :members:
    :undoc-members:
    :show-inheritance:


